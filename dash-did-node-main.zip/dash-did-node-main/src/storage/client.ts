import Dash from 'dash';

export const client = new Dash.Client();
