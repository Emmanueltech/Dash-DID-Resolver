import express, { Express, Request, Response } from 'express';
import dotenv from 'dotenv';

import bodyParser from 'body-parser';
import morgan from 'morgan';
import { Resolve } from './handlers/resolve'

dotenv.config();

const app: Express = express();
const port: string | undefined = process.env.PORT;

app.use(bodyParser.json())
app.use(morgan('short'))

app.get("/identifiers/:identifier", Resolve)

app.listen(port, () => {
  console.log(`[server]: Server is running at http://localhost:${port}`);
});
