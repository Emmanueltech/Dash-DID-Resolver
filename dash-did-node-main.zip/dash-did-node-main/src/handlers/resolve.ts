import { Request, Response } from 'express';
import { DID } from '../storage/did';
import { DIDDocument, EcdsaSecp256k1VerificationKey2019, VerificationMethod } from '../storage/document';
import { getDashIdentity } from '../storage/getIdentity'


export async function Resolve(req: Request, res: Response) {

    const identifier: string = req.params.identifier;
    let did: DID = new DID(identifier);
    await did.initialize();

    let doc: DIDDocument = new DIDDocument(identifier);
    doc.id = did.toString();

    const id = await getDashIdentity(did.data || "");

    const idData: Buffer = id['publicKeys'][0]['data']
    const hexPubKey:string = idData.toString("hex")


    let verif: VerificationMethod = new EcdsaSecp256k1VerificationKey2019(did.toString(), did.toString(), hexPubKey)
    doc.verificationMethod = verif;
    res.json(doc)
}
